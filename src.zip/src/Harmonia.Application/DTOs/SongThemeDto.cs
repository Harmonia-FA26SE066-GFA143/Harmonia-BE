namespace Harmonia.Application.DTOs;

public class SongThemeDto
{
    public Guid Id { get; set; }

    public string Name { get; set; } = string.Empty;

    public string? Description { get; set; }
}
